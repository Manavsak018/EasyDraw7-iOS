import SwiftUI

struct Stroke { var points: [CGPoint] }

struct ContentView: View {
    @State private var strokes: [Stroke] = []
    @State private var current: [CGPoint] = []
    @State private var jogMM = 10.0
    @State private var speed = 30.0

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    HStack {
                        Circle().fill(.orange).frame(width: 9, height: 9)
                        Text("USB DATA NOT VERIFIED").font(.caption.bold())
                        Spacer()
                        Text("MakerQ EasyDraw V3").font(.caption).foregroundStyle(.secondary)
                    }.padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))

                    VStack(alignment: .leading) {
                        Text("Freehand drawing").font(.headline)
                        GeometryReader { geo in
                            ZStack {
                                Color.white
                                Canvas { ctx, size in
                                    var grid = Path()
                                    for x in stride(from: 0.0, through: size.width, by: 20) {
                                        grid.move(to: CGPoint(x: x, y: 0)); grid.addLine(to: CGPoint(x: x, y: size.height))
                                    }
                                    for y in stride(from: 0.0, through: size.height, by: 20) {
                                        grid.move(to: CGPoint(x: 0, y: y)); grid.addLine(to: CGPoint(x: size.width, y: y))
                                    }
                                    ctx.stroke(grid, with: .color(.gray.opacity(0.15)), lineWidth: 0.5)
                                    for s in strokes {
                                        var p = Path()
                                        guard let first = s.points.first else { continue }
                                        p.move(to: first); s.points.dropFirst().forEach { p.addLine(to: $0) }
                                        ctx.stroke(p, with: .color(.black), style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                                    }
                                    if let first = current.first {
                                        var p = Path(); p.move(to: first)
                                        current.dropFirst().forEach { p.addLine(to: $0) }
                                        ctx.stroke(p, with: .color(.blue), style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                                    }
                                }
                                .contentShape(Rectangle())
                                .gesture(DragGesture(minimumDistance: 0)
                                    .onChanged { v in current.append(v.location) }
                                    .onEnded { _ in if !current.isEmpty { strokes.append(Stroke(points: current)); current = [] } })
                            }
                        }.frame(height: 300).clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(.gray.opacity(0.4)))
                        HStack {
                            Button("Undo") { if !strokes.isEmpty { strokes.removeLast() } }.buttonStyle(.bordered)
                            Button("Clear") { strokes.removeAll(); current.removeAll() }.buttonStyle(.bordered)
                            Spacer()
                            Text("\(strokes.count) strokes").font(.caption).foregroundStyle(.secondary)
                        }
                    }.padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))

                    VStack(alignment: .leading) {
                        HStack { Text("Jog distance"); Spacer(); Text("\(Int(jogMM)) mm").bold() }
                        Slider(value: $jogMM, in: 1...100, step: 1)
                        HStack { Text("1 mm"); Spacer(); Text("100 mm") }.font(.caption).foregroundStyle(.secondary)
                    }.padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))

                    VStack(alignment: .leading) {
                        HStack { Text("Requested speed"); Spacer(); Text("\(Int(speed)) mm/s").bold() }
                        Slider(value: $speed, in: 10...150, step: 1)
                        HStack { Text("10 mm/s"); Spacer(); Text("150 mm/s") }.font(.caption).foregroundStyle(.secondary)
                    }.padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))

                    VStack(spacing: 12) {
                        HStack { ForEach(["↑", "←", "→", "↓"], id: \.self) { Button($0) {}.buttonStyle(.bordered).disabled(true) } }
                        HStack { Button("PEN UP") {} ; Button("PEN DOWN") {} }.buttonStyle(.bordered).disabled(true)
                        HStack {
                            Button("PLOT") {}; Button("PAUSE") {}; Button("RESUME") {}; Button("STOP") {}
                        }.buttonStyle(.borderedProminent).disabled(true)
                        Text("Motion controls are disabled until a supported USB data transport is implemented and tested.")
                            .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }.padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
                }.padding()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("EasyDraw 7")
        }
    }
}
