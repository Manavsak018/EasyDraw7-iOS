import SwiftUI
@main struct EasyDraw7iOSApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}
