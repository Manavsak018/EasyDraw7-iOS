# EasyDraw 7 iPhone UI prototype

SwiftUI starter project for iPhone. Includes freehand stroke capture, jog distance slider (1–100 mm), speed slider (10–150 mm/s), and plotter control UI.

IMPORTANT: This is a UI prototype only. It does not send USB commands. The plotter lighting up confirms power, not USB data communication. Apple's standard External Accessory framework is for supported MFi accessories and is not a generic USB-serial API. A compatible transport/driver must be established before enabling real motion.

Open EasyDraw7iOS.xcodeproj in Xcode on a Mac, choose an iPhone target, set signing, and build. Minimum iOS 16.
